<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <!-- Total Websites -->
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                            </svg>
                        </div>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">Total Websites</dt>
                            <dd class="text-lg font-semibold text-gray-900 dark:text-white" id="total-websites"><?php echo e(number_format($totalWebsites)); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Visits -->
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                            </svg>
                        </div>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">Total Visits</dt>
                            <dd class="text-lg font-semibold text-gray-900 dark:text-white" id="total-visits"><?php echo e(number_format($totalVisits)); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Logs -->
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                        </div>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">Total Logs</dt>
                            <dd class="text-lg font-semibold text-gray-900 dark:text-white" id="total-logs"><?php echo e(number_format($totalLogs)); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <!-- Today Visits -->
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <div class="flex items-center justify-center h-12 w-12 rounded-md bg-yellow-500 text-white">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">Today Visits</dt>
                            <dd class="text-lg font-semibold text-gray-900 dark:text-white" id="today-visits"><?php echo e(number_format($todayVisits)); ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Visitor Logs -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg">
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Recent Visitor Logs</h3>
                <a href="<?php echo e(route('analytics.index')); ?>" class="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">
                    View All
                </a>
            </div>
            <div class="p-6">
                <?php if($recentLogs->count() > 0): ?>
                    <div class="space-y-4 recent-logs-container">
                        <?php $__currentLoopData = $recentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-start">
                                <div class="flex-shrink-0">
                                    <div class="h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/20 flex items-center justify-center">
                                        <svg class="w-5 h-5 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-4 flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                        <a href="<?php echo e(route('website.show', $log->website_id)); ?>" class="hover:text-indigo-600 dark:hover:text-indigo-400">
                                            <?php echo e($log->website->name ?? 'Unknown Website'); ?>

                                        </a>
                                    </p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400 truncate">
                                        <?php echo e($log->ip_address); ?> • <?php echo e($log->visited_at ? \Carbon\Carbon::parse($log->visited_at)->diffForHumans() : 'N/A'); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <svg class="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">No visitor logs yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Top Websites -->
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg">
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Top Websites</h3>
                <a href="<?php echo e(route('website.index')); ?>" class="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">
                    View All
                </a>
            </div>
            <div class="p-6">
                <?php if($topWebsites->count() > 0): ?>
                    <div class="space-y-4 top-websites-container">
                        <?php $__currentLoopData = $topWebsites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center flex-1 min-w-0">
                                    <div class="flex-shrink-0">
                                        <?php if($index < 3): ?>
                                            <span class="flex items-center justify-center w-8 h-8 rounded-full <?php echo e($index === 0 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400' : ($index === 1 ? 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-300' : 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400')); ?> font-semibold text-sm">
                                                <?php echo e($index + 1); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 font-semibold text-sm">
                                                <?php echo e($index + 1); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-3 flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                            <a href="<?php echo e(route('website.show', $website->id)); ?>" class="hover:text-indigo-600 dark:hover:text-indigo-400">
                                                <?php echo e($website->name); ?>

                                            </a>
                                        </p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                                            <?php echo e(number_format($website->total_visit ?? 0)); ?> visits
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <svg class="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">No websites yet</p>
                        <a href="<?php echo e(route('website.create')); ?>" class="mt-4 inline-flex items-center px-4 py-2 text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">
                            Add your first website
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Monthly Visits per Website</h3>
        </div>
        <div class="p-6">
            <div id="traffic-chart" style="height: 350px;"></div>
        </div>
    </div>
    <!-- Quick Actions -->
    <div class="bg-white dark:bg-gray-800 shadow rounded-lg">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Quick Actions</h3>
        </div>
        <div class="p-6">
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <a href="<?php echo e(route('website.create')); ?>" class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-colors">
                    <svg class="w-8 h-8 text-gray-400 dark:text-gray-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Add Website</span>
                </a>
                <a href="<?php echo e(route('website.index')); ?>" class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-colors">
                    <svg class="w-8 h-8 text-gray-400 dark:text-gray-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                    </svg>
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Manage Websites</span>
                </a>
                <a href="<?php echo e(route('analytics.index')); ?>" class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-colors">
                    <svg class="w-8 h-8 text-gray-400 dark:text-gray-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">View Analytics</span>
                </a>
                <a href="<?php echo e(route('website.index')); ?>" class="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg hover:border-indigo-500 dark:hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-colors">
                    <svg class="w-8 h-8 text-gray-400 dark:text-gray-500 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Reports</span>
                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script>
    let lastLogCount = <?php echo e($totalLogs); ?>;
    let pollingInterval;

    document.addEventListener('DOMContentLoaded', function() {
        // Start polling every 60 seconds
        startPolling();
    });

    function startPolling() {
        // Poll immediately on load
        fetchDashboardStats();

        // Then poll every 60 seconds
        pollingInterval = setInterval(fetchDashboardStats, 60000);
    }

    function fetchDashboardStats() {
        axios.get('<?php echo e(route("api.dashboard.stats")); ?>')
            .then(function(response) {
                if (response.data.success) {
                    const data = response.data.data;

                    // Update stats
                    updateStatCard('total-websites', data.stats.total_websites);
                    updateStatCard('total-visits', data.stats.total_visits);
                    updateStatCard('total-logs', data.stats.total_logs);
                    updateStatCard('today-visits', data.stats.today_visits);

                    // Check if there are new logs
                    if (data.stats.total_logs > lastLogCount) {
                        const newLogsCount = data.stats.total_logs - lastLogCount;
                        if (newLogsCount > 0) {
                            updateRecentLogs(data.recent_logs);
                            showNotification(`New ${newLogsCount} visitor(s) tracked`);
                        }
                        lastLogCount = data.stats.total_logs;
                    }

                    // Update top websites
                    updateTopWebsites(data.top_websites);
                }
            })
            .catch(function(error) {
                console.error('Error fetching dashboard stats:', error);
            });
    }

    function updateStatCard(id, value) {
        const element = document.getElementById(id);
        if (element) {
            const currentValue = parseInt(element.textContent.replace(/,/g, '')) || 0;
            const newValue = parseInt(value) || 0;

            if (currentValue !== newValue) {
                animateValue(element, currentValue, newValue, 500);
            }
        }
    }

    function animateValue(element, start, end, duration) {
        const range = end - start;
        if (range === 0) return;

        const increment = range / (duration / 16);
        let current = start;

        const timer = setInterval(() => {
            current += increment;
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                current = end;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current).toLocaleString();
        }, 16);
    }

    function updateRecentLogs(logs) {
        const container = document.querySelector('.recent-logs-container');
        if (!container) return;

        // Clear existing logs
        container.innerHTML = '';

        // Add new logs
        logs.forEach((log, index) => {
            const logElement = document.createElement('div');
            logElement.className = index === 0 ? 'flex items-start animate-pulse' : 'flex items-start';
            logElement.innerHTML = `
                <div class="flex-shrink-0">
                    <div class="h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/20 flex items-center justify-center">
                        <svg class="w-5 h-5 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                        </svg>
                    </div>
                </div>
                <div class="ml-4 flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                        <a href="/app/private/website/${log.website_id}" class="hover:text-indigo-600 dark:hover:text-indigo-400">
                            ${log.website.name}
                        </a>
                    </p>
                    <p class="text-sm text-gray-500 dark:text-gray-400 truncate">
                        ${log.ip_address} • ${log.visited_at_human}
                    </p>
                </div>
            `;

            if (index === 0) {
                setTimeout(() => {
                    logElement.classList.remove('animate-pulse');
                }, 1000);
            }

            container.appendChild(logElement);
        });
    }

    function updateTopWebsites(websites) {
        const container = document.querySelector('.top-websites-container');
        if (!container) return;

        container.innerHTML = '';

        websites.forEach((website, index) => {
            const websiteElement = document.createElement('div');
            websiteElement.className = 'flex items-center justify-between';
            websiteElement.innerHTML = `
                <div class="flex items-center flex-1 min-w-0">
                    <div class="flex-shrink-0">
                        ${index < 3 ?
                            `<span class="flex items-center justify-center w-8 h-8 rounded-full ${index === 0 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400' : (index === 1 ? 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-300' : 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400')} font-semibold text-sm">
                                ${index + 1}
                            </span>` :
                            `<span class="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 font-semibold text-sm">
                                ${index + 1}
                            </span>`
                        }
                    </div>
                    <div class="ml-3 flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                            <a href="/app/private/website/${website.id}" class="hover:text-indigo-600 dark:hover:text-indigo-400">
                                ${website.name}
                            </a>
                        </p>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                            ${parseInt(website.total_visit).toLocaleString()} visits
                        </p>
                    </div>
                </div>
            `;
            container.appendChild(websiteElement);
        });
    }
    document.addEventListener('DOMContentLoaded', function () {
    loadMonthlyChart();
});

function loadMonthlyChart() {
    axios.get('<?php echo e(route("api.dashboard.chart.permonth")); ?>')
        .then(function(response) {
            if (response.data.success) {

                Highcharts.chart('traffic-chart', {
                    chart: {
                        type: 'column',
                        backgroundColor: 'transparent'
                    },
                    title: {
                        text: 'Monthly Visits Comparison'
                    },
                    xAxis: {
                        categories: response.data.months,
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Total Visits'
                        },
                    },
                    tooltip: {
                        shared: true,
                        valueSuffix: ' visits'
                    },
                    plotOptions: {
                        column: {
                            pointPadding: 0.1,
                            borderWidth: 0,
                            dataLabels: {
                                enabled: true,
                                style: { color: '#ccc' }
                            }
                        }
                    },
                    series: response.data.series,
                    credits: {
                        enabled: false
                    }
                });

            }
        })
        .catch(function(error) {
            console.error('Chart load error:', error);
        });
}
    function showNotification(message) {
        // Remove existing notification if any
        const existing = document.querySelector('.live-notification');
        if (existing) {
            existing.remove();
        }

        const notification = document.createElement('div');
        notification.className = 'live-notification fixed top-4 right-4 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-slide-in';
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('animate-slide-out');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (pollingInterval) {
            clearInterval(pollingInterval);
        }
    });
</script>

<style>
    @keyframes slide-in {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slide-out {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }

    .animate-slide-in {
        animation: slide-in 0.3s ease-out;
    }

    .animate-slide-out {
        animation: slide-out 0.3s ease-out;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myproject\tracking_website\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>